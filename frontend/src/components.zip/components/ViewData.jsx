import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Diary from "../assets/opendiary2.png";

const ViewData = ({ setCurrentPage, handleUpload }) => {
    const [selectedDate, setSelectedDate] = useState(new Date()); // Initialize with current date
    const [textValue, setTextValue] = useState(`Selected Date: ${new Date().toDateString()}`);
    const [data, setData] = useState(''); // State to hold form input
    const [images, setImages] = useState([]); // State to hold uploaded images
    const [isAddingData, setIsAddingData] = useState(false); // State to toggle between calendar and add data form

    // Function to handle date change
    const handleDateChange = (event) => {
        const newDate = new Date(event.target.value);
        setSelectedDate(newDate);
        setTextValue(`Selected Date: ${newDate.toDateString()}`);
    };

    // Effect to reset selectedDate if it's null or invalid
    useEffect(() => {
        if (!selectedDate || isNaN(selectedDate.getTime())) {
            setSelectedDate(new Date()); // Set to current date if no valid date is selected
        }
    }, [selectedDate]);

    // Handle input change
    const handleDataChange = (event) => {
        setData(event.target.value);
    };

    // Handle form submission
    const handleSubmit = (event) => {
        event.preventDefault();
        if (selectedDate && data.trim() !== '') {
            handleUpload(selectedDate, data); // Call the handleUpload function passed via props
            setData(''); // Clear the text area after submission
            setTextValue(`Selected Date: ${new Date().toLocaleDateString()}`); // Reset text value
            setIsAddingData(false); // Hide the add data form
        } else {
            alert('Please enter data before adding.');
        }
    };

    // Handle image upload
    const handleImageUpload = (event) => {
        const files = Array.from(event.target.files);
        const newImages = files.map(file => URL.createObjectURL(file));
        setImages(prevImages => [...prevImages, ...newImages]);
    };
    const imageinp = useRef(null);
    const handleAddImage = () => {
        imageinp.current.click();
    }
    return (
        <div style={{ padding: '20px' }}>
            <div
                style={{
                    width: '93%',
                    height: '60px',
                    display: 'flex',
                    marginLeft: '50px',
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <label style={{ marginRight: '10px' }}>Select a Date:</label>
                <input
                    type="date"
                    value={selectedDate.toISOString().substr(0, 10)}
                    onChange={handleDateChange}
                    style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ccc' }}
                />
            </div>
            <div
                style={{
                    width: '803px',
                    height: '552.5px',
                    margin: 'auto',
                    padding: '20px',
                    backgroundImage: `url(${Diary})`,
                    backgroundPosition: 'center',
                    backgroundSize: 'cover'
                }}
            >
                {/* Container for Left and Right Divs */}
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    {/* Left Div for Random Images */}
                    <div
                        style={{
                            width: '44%',
                            height: '510px',
                            marginLeft: '50px',
                            backgroundColor: 'transparent',
                            padding: '10px',
                            overflowY: 'auto', // Enable scrolling if content overflows
                        }}
                    >
                        <input
                            type="file"
                            accept="image/*"
                            ref={imageinp}
                            multiple
                            onChange={handleImageUpload}
                            style={{display:'none'}}
                        />
                        {images.map((image, index) => (
                            <img key={index} src={image} alt={`Random ${index}`} style={{ width: '100%', marginBottom: '10px' }} />
                        ))}
                    </div>

                    {/* Right Div for Text Area */}
                    <div
                        style={{
                            width: '47%',
                            height: '500px',
                            marginTop: '5px',
                            marginRight: '5px',
                            backgroundColor: 'transparent',
                            padding: '10px',
                        }}
                    >
                        <textarea
                            style={{
                                height: '102%',
                                width: '100%',
                                padding: '10px',
                                border: 'none',
                                outline: 'none',
                                resize: 'none',
                                boxSizing: 'border-box',
                                backgroundColor: 'transparent',
                            }}
                            value={data}
                            onChange={handleDataChange}
                        />
                        
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ViewData;



// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import Diary from "../assets/opendiary2.png";

// const ViewData = () => {
//   const [entries, setEntries] = useState([]);

//   useEffect(() => {
//     const fetchEntries = async () => {
//       const userId = localStorage.getItem('userId'); // Assuming user ID is stored here
//       try {
//         const response = await axios.get('/api/diary/get-entries', {
//           params: { userId },
//         });
//         setEntries(response.data); // Store fetched entries
//       } catch (error) {
//         console.error('Error fetching diary entries:', error);
//       }
//     };

//     fetchEntries();
//   }, []);

//   return (
//     <div style={{ padding: '20px' }}>
//       <div
//         style={{
//           width: '803px',
//           height: '552.5px',
//           margin: 'auto',
//           padding: '20px',
//           backgroundImage: `url(${Diary})`,
//           backgroundPosition: 'center',
//           backgroundSize: 'cover'
//         }}
//       >
//         {entries.length > 0 ? (
//           entries.map((entry) => (
//             <div key={entry.entryId} style={{ marginBottom: '20px' }}>
//               <h3 style={{ marginBottom: '10px' }}>{new Date(entry.entryDate).toDateString()}</h3>
//               <p>{entry.content}</p>
//               {entry.imageUrl && (
//                 <img
//                   src={entry.imageUrl}
//                   alt="Diary Entry"
//                   style={{
//                     width: '300px',
//                     height: 'auto',
//                     marginTop: '10px',
//                     borderRadius: '8px',
//                     boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
//                   }}
//                 />
//               )}
//             </div>
//           ))
//         ) : (
//           <p>No diary entries found.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default ViewData;
