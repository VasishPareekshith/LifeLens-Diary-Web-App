import React from 'react';
import { Link} from 'react-router-dom';
const Navbar = ({ setCurrentPage }) => {
    return (
        <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'none', width: '100%' }}>
            <ul style={{ listStyleType: 'none', display: 'flex', padding: '0', margin: '0' }}>
                <li style={{ marginRight: '20px' }}>
                    <button
                        onClick={() => setCurrentPage('calendar')}
                        style={{
                            padding: '10px 20px',
                            borderRadius: '5px',
                            border: 'none',
                            backgroundColor: '#4CAF50',
                            color: '#fff',
                            cursor: 'pointer',
                            fontSize: '50px',
                            fontFamily: 'Dancing Script, cursive'
                        }}
                    >
                        Add Entry
                    </button>
                </li>
                <li>
                    <button
                        onClick={() => setCurrentPage('viewdata')}
                        style={{
                            padding: '10px 20px',
                            borderRadius: '5px',
                            border: 'none',
                            backgroundColor: '#4CAF50',
                            color: '#fff',
                            cursor: 'pointer',
                            fontSize: '50px',
                            fontFamily: 'Dancing Script, cursive'
                        }}
                    >
                        View Timeline
                    </button>
                </li>
            </ul>
            
            {/* Profile Button */}
            <div style={{ marginLeft: 'auto' }}>
                <Link to="/profile" style={{ textDecoration: 'none' }}>
                    <button
                        style={{
                            padding: '10px 20px',
                            borderRadius: '5px',
                            border: 'none',
                            backgroundColor: '#4CAF50',
                            color: '#fff',
                            cursor: 'pointer',
                            fontSize: '50px',
                            fontFamily: 'Dancing Script, cursive'
                        }}
                    >
                        Profile
                    </button>
                </Link>
            </div>
        </nav>
    );
};

export default Navbar;

