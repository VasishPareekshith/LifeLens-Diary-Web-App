import React from 'react';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
    const userProfile = {
        name: "John Doe",
        email: "john.doe@example.com",
        profilePicture: "https://via.placeholder.com/1024", // Placeholder image
    };

    const navigate = useNavigate();  // Initialize useNavigate

    const handleBack = () => {
        navigate(-1);  // Navigate to the previous page (-1 goes back in history)
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '50px' }}>
            {/* Profile Picture */}
            <img
                src={userProfile.profilePicture}
                alt="Profile"
                style={{ borderRadius: '50%', width: '150px', height: '150px', marginBottom: '20px' }}
            />

            {/* User Name */}
            <h1 style={{ fontSize: '36px', color: '#4CAF50' }}>{userProfile.name}</h1>

            {/* Email */}
            <p style={{ fontSize: '24px', color: '#555' }}>{userProfile.email}</p>

            {/* Edit Profile Button */}
            <button
                style={{
                    padding: '10px 20px',
                    borderRadius: '5px',
                    border: 'none',
                    backgroundColor: '#4CAF50',
                    color: '#fff',
                    cursor: 'pointer',
                    marginTop: '20px',
                    fontSize: '18px',
                }}
                onClick={() => alert("Edit profile feature coming soon!")}
            >
                Edit Profile
            </button>
            {/* Back Button */}
            <button
                style={{
                    padding: '10px 20px',
                    borderRadius: '5px',
                    border: 'none',
                    backgroundColor: '#f44336',
                    color: '#fff',
                    cursor: 'pointer',
                    marginTop: '20px',
                    fontSize: '18px',
                }}
                onClick={handleBack}  // Call handleBack onClick
            >
                Back
            </button>
        </div>
    );
};

export default Profile;
